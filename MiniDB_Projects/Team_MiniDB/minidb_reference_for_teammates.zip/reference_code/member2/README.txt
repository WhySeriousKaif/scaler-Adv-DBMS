# Member 2 Reference Code

Copy each folder into `MiniDB_Projects/Team_MiniDB/src/`:

```
member2/index/      → src/index/
member2/catalog/    → src/catalog/
member2/parser/     → src/parser/
member2/optimizer/  → src/optimizer/
```

Then commit and push. Read every file before viva!
