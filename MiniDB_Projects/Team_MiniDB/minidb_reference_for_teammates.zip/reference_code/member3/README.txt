# Member 3 Reference Code

Copy into MiniDB_Projects/Team_MiniDB/:

```
member3/execution/     → src/execution/
member3/transaction/   → src/transaction/
member3/recovery/      → src/recovery/
member3/performance/   → src/performance/
member3/Database.hpp   → src/Database.hpp
member3/Database.cpp   → src/Database.cpp
member3/main.cpp       → src/main.cpp  (replaces Member 1 demo)
member3/Makefile       → Makefile      (replaces)
member3/CMakeLists.txt → CMakeLists.txt
```

Then: make && ./minidb

Also add README_VIVA.md and complete README.md before final PR.
